# Housing Price Prediction App

This project is a web application for predicting housing prices using a machine learning model. The application is structured into two main components: the backend and the frontend.

## Project Structure

```
housing-price-prediction-app
├── backend
│   ├── app.py                # Entry point for the backend application
│   ├── model
│   │   └── predictor.py      # Contains the Predictor class for model handling
│   ├── requirements.txt       # Lists backend dependencies
│   └── README.md              # Documentation for the backend
├── frontend
│   ├── static
│   │   └── style.css         # CSS styles for the frontend
│   ├── templates
│   │   └── index.html        # Main HTML template for the frontend
│   └── README.md              # Documentation for the frontend
└── README.md                  # Overview of the entire project
```

## Backend

The backend is built using Flask and handles the logic for predicting housing prices. It includes:

- **app.py**: The main application file that initializes the Flask app and sets up the necessary routes.
- **predictor.py**: Contains the `Predictor` class, which loads the trained model and provides methods for making predictions.
- **requirements.txt**: A file that lists all the required Python packages for the backend.

### Setup Instructions

1. Navigate to the `backend` directory.
2. Install the required packages using pip:
   ```
   pip install -r requirements.txt
   ```
3. Run the application:
   ```
   python app.py
   ```

## Frontend

The frontend is built using HTML, CSS, and JavaScript. It provides a user interface for users to input data and receive predictions. It includes:

- **style.css**: Contains the styles for the web application.
- **index.html**: The main HTML file that serves as the user interface.

### Setup Instructions

1. Navigate to the `frontend` directory.
2. Open `index.html` in a web browser to view the application.

## Usage

Once both the backend and frontend are set up, you can access the application through your web browser. Input the required housing features, and the application will return the predicted price based on the trained model.

## Contributing

Contributions are welcome! Please feel free to submit a pull request or open an issue for any suggestions or improvements.