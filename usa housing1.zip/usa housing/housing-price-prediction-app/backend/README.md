# Housing Price Prediction Backend

This is the backend component of the Housing Price Prediction application. It is built using Flask and serves as the API for predicting housing prices based on user input.

## Setup Instructions

1. **Clone the repository:**
   ```
   git clone <repository-url>
   cd housing-price-prediction-app/backend
   ```

2. **Create a virtual environment (optional but recommended):**
   ```
   python -m venv venv
   source venv/bin/activate  # On Windows use `venv\Scripts\activate`
   ```

3. **Install the required dependencies:**
   ```
   pip install -r requirements.txt
   ```

4. **Run the application:**
   ```
   python app.py
   ```

   The application will start on `http://127.0.0.1:5000`.

## Usage

To make predictions, send a POST request to the `/predict` endpoint with the required input data in JSON format. 

### Example Request

```json
{
    "feature1": value1,
    "feature2": value2,
    ...
}
```

### Example Response

```json
{
    "predicted_price": predicted_value
}
```

## Directory Structure

- `app.py`: Entry point of the backend application.
- `model/predictor.py`: Contains the Predictor class for loading the model and making predictions.
- `requirements.txt`: Lists the dependencies required for the backend application.